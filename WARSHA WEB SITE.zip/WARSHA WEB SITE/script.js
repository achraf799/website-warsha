

const currentLocation = location.href;
const menuItem = document.querySelectorAll('nav ul li a');
const menuLength = menuItem.length;

for (let i = 0; i < menuLength; i++) {
  if (menuItem[i].href === currentLocation) {
    menuItem[i].classList.add('active'); 
  }
}



function toggleMenu() {
    var menuList = document.getElementById("menuList");
    var menuIcon = document.getElementById("menu-icon");
    var navlist = document.querySelector(".navlist");

    menuList.classList.toggle("open");
    menuIcon.classList.toggle("bx-x");
    navlist.classList.toggle("open");
}
// // Get the current page URL
// var currentPageURL = window.location.href;

// // Get all the <a> elements in the navigation menu
// var menuLinks = document.querySelectorAll('#menuList li a');

// // Loop through the menu links and check if the link's href matches the current page URL
// for (var i = 0; i < menuLinks.length; i++) {
//   if (menuLinks[i].href === currentPageURL) {
//     // Add the 'active' class to the link if it's the current page
//     menuLinks[i].classList.add('active');
//     break; // Stop the loop since we found the active link
//   }
// }

function sendEmail(){
    Email.send({
        Host : "smtp.warsha-dz.com",
        Username : "boudiafmohammedachrafeddine@warsha-dz.com",
        Password : "Crv222003@",
        To : 'boudiafmohammedachrafeddine@warsha-dz.com',
        From : document.getElementById("mailfrom").value,
        Subject : "New contact form enquiry",
        Body : "Name" + document.getElementById("name").value +
        "From" + document.getElementById("mailfrom").value +
        "Subject" + document.getElementById("subject").value +
        "Message" + document.getElementById("message").value 
    }).then(
      message => alert("Message sent succesfully")
    );
}